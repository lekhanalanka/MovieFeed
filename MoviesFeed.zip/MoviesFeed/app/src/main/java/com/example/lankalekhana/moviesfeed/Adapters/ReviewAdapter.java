package com.example.lankalekhana.moviesfeed.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lankalekhana.moviesfeed.ModelClasses.ReviewModel;
import com.example.lankalekhana.moviesfeed.R;

import java.util.ArrayList;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.ReviewHolder> {

    Context context;
    ArrayList<ReviewModel> reviewModelArrayList;

    public ReviewAdapter(Context context, ArrayList<ReviewModel> reviewModelArrayList)
    {
        this.context = context;
        this.reviewModelArrayList = reviewModelArrayList;

    }

    @NonNull
    @Override
    public ReviewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(context).inflate(R.layout.review,viewGroup,false);
        return new ReviewAdapter.ReviewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReviewHolder reviewHolder, int i) {

            reviewHolder.author.setText(reviewModelArrayList.get(i).getAuthor());
            reviewHolder.content.setText(reviewModelArrayList.get(i).getContent());

    }

    @Override
    public int getItemCount() {
        return reviewModelArrayList.size();
    }

    public class ReviewHolder extends RecyclerView.ViewHolder {

        TextView author,content;

        public ReviewHolder(@NonNull View itemView) {
            super(itemView);

            author = (itemView).findViewById(R.id.author_tv);
            content = (itemView).findViewById(R.id.content_tv);

        }
    }
}
