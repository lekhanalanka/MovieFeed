package com.example.lankalekhana.moviesfeed.Adapters;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.lankalekhana.moviesfeed.ModelClasses.TrailerModelClass;
import com.example.lankalekhana.moviesfeed.R;

import java.util.ArrayList;

public class TrailerAdapter extends RecyclerView.Adapter<TrailerAdapter.TrailerHolder> {

    Context context;
    ArrayList<TrailerModelClass> trailersModelClasses;

    public TrailerAdapter(Context context, ArrayList<TrailerModelClass> tail) {

        this.trailersModelClasses=tail;
        this.context=context;
    }

    @NonNull
    @Override
    public TrailerHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View view = LayoutInflater.from(context).inflate(R.layout.trailer,viewGroup,false);
        return new TrailerAdapter.TrailerHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull TrailerHolder trailerHolder, int i) {

        trailerHolder.trailer_tv.setText(trailersModelClasses.get(i).getName());

    }

    @Override
    public int getItemCount() {
        return trailersModelClasses.size();
    }

    public class TrailerHolder extends RecyclerView.ViewHolder {

        TextView trailer_tv;
        public TrailerHolder(@NonNull View itemView) {
            super(itemView);

            trailer_tv=itemView.findViewById(R.id.tv_tailer);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position=getAdapterPosition();
                    String key =trailersModelClasses.get(position).getKey();
                    Uri link =Uri.parse("https://www.youtube.com/watch?v="+key);
                    Intent intent = new Intent(Intent.ACTION_VIEW,link);
                    context.startActivity(intent);
                }
            });

        }
    }
}
