package com.example.lankalekhana.moviesfeed.DAO;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.lankalekhana.moviesfeed.AsyncClasses.FavouriteClass;

import java.util.List;

@Dao

public interface DataAccessObject
{
    @Query("SELECT * FROM Favourite_Movies")
    LiveData<List<FavouriteClass>> getData();

    @Query("SELECT * FROM Favourite_Movies WHERE id == :id")
    FavouriteClass checkFavoriteMovie(String id);

    @Insert
    void insert(FavouriteClass fav_movies);

    @Delete
    void delete(FavouriteClass fav_movies);
}
