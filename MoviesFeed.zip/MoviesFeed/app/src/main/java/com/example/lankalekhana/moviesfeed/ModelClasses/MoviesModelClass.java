package com.example.lankalekhana.moviesfeed.ModelClasses;

public class MoviesModelClass
{
    String id,poster,title,release_date,vote_avg,overview;

    public MoviesModelClass(String id, String poster, String title, String release_date, String vote_avg, String overview)
    {
        this.id=id;
        this.poster=poster;
        this.title=title;
        this.release_date=release_date;
        this.vote_avg=vote_avg;
        this.overview=overview;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getRelease_date() {
        return release_date;
    }

    public void setRelease_date(String release_date) {
        this.release_date = release_date;
    }

    public String getVote_avg() {
        return vote_avg;
    }

    public void setVote_avg(String vote_avg) {
        this.vote_avg = vote_avg;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }
}
