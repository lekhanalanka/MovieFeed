package com.example.lankalekhana.moviesfeed;

import android.arch.lifecycle.ViewModelProviders;
import android.arch.persistence.room.Room;
import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lankalekhana.moviesfeed.Adapters.TrailerAdapter;
import com.example.lankalekhana.moviesfeed.AsyncClasses.FavouriteClass;
import com.example.lankalekhana.moviesfeed.AsyncClasses.ReviewAsync;

import com.example.lankalekhana.moviesfeed.DAO.DataBase;
import com.example.lankalekhana.moviesfeed.ModelClasses.FavModelClass;
import com.example.lankalekhana.moviesfeed.ModelClasses.ReviewModel;
import com.example.lankalekhana.moviesfeed.ModelClasses.TrailerModelClass;
import com.github.ivbaranov.mfb.MaterialFavoriteButton;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class DetailsActivity extends AppCompatActivity {

    TextView avg, release, id, title, overview;
    ImageView img;
    String imageId, title_text, release_date, vote_avg, over_View,id1,auth,rv;
    ArrayList<ReviewModel> rev;
    ArrayList<TrailerModelClass> trailer;
    MaterialFavoriteButton materialFavoriteButton;
    RecyclerView recyc_review,recyc_trailer;
    DataBase dataBase;
    List<FavouriteClass> arrayList;
    FavModelClass favouriteModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        favouriteModel = ViewModelProviders.of(DetailsActivity.this).get(FavModelClass.class);
        avg = findViewById(R.id.vote_average);
        title = findViewById(R.id.title_tv);
        release = findViewById(R.id.release);
        overview = findViewById(R.id.overview);
        img = findViewById(R.id.image_v);
        id = findViewById(R.id.id_tv);
        materialFavoriteButton = findViewById(R.id.favButton);
        recyc_review = findViewById(R.id.recy_overview);
        recyc_trailer=findViewById(R.id.recy_trailer);
        arrayList = new ArrayList<>();

        dataBase = Room.databaseBuilder(this, DataBase.class, "movies.db")
                .allowMainThreadQueries()
                .build();

        imageId = getIntent().getStringExtra("posterPath");
        title_text = getIntent().getStringExtra("title");
        release_date = getIntent().getStringExtra("release");
        vote_avg = getIntent().getStringExtra("avg");
        over_View = getIntent().getStringExtra("overview");
        id1 = getIntent().getStringExtra("id");

        dataBase = Room.databaseBuilder(this, DataBase.class, "movies.db").fallbackToDestructiveMigration().allowMainThreadQueries().build();
        checkmovie();

        materialFavoriteButton.setOnFavoriteChangeListener(new MaterialFavoriteButton.OnFavoriteChangeListener() {
            @Override
            public void onFavoriteChanged(MaterialFavoriteButton buttonView, boolean favorite) {
                if (favorite) {
                    FavouriteClass fav_movies = new FavouriteClass();
                    fav_movies.setVote_avg(vote_avg);
                    fav_movies.setPoster_path(imageId);
                    fav_movies.setMov_name(title_text);
                    fav_movies.setRelease_date(release_date);
                    fav_movies.setOverView(over_View);
                    fav_movies.setId(Integer.parseInt(id1));
                    favouriteModel.insert(fav_movies);
                } else {

                    FavouriteClass fav_movies = new FavouriteClass();
                    fav_movies.setVote_avg(vote_avg);
                    fav_movies.setPoster_path(imageId);
                    fav_movies.setMov_name(title_text);
                    fav_movies.setRelease_date(release_date);
                    fav_movies.setOverView(over_View);
                    fav_movies.setId(Integer.parseInt(id1));
                    favouriteModel.delete(fav_movies);
                }
            }
        });
        title.setText(title_text);
        release.setText(release_date);
        avg.setText(vote_avg);
        overview.setText(over_View);
        id.setText(id1);
        Picasso.with(this).load(imageId).into(img);
        review();
        trailer();

    }

    private void checkmovie() {

        FavouriteClass selectedID = favouriteModel.searchForMovie(id1);
        if (selectedID !=null) {
            materialFavoriteButton.setFavorite(true);
        } else {
            materialFavoriteButton.setFavorite(false);
        }
    }

    private void trailer() {

        TrailerAsync trailerAsync = new TrailerAsync(this,trailer,recyc_trailer);
        trailerAsync.execute(id1);
    }

    private void review() {

        ReviewAsync review = new ReviewAsync(this, rev, recyc_review);
        review.execute(id1);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public class TrailerAsync extends AsyncTask<String,Void,String> {

        Context context;
        ArrayList<TrailerModelClass> tail;
        RecyclerView trailerRecycler;

        public TrailerAsync(DetailsActivity detailsActivity, ArrayList<TrailerModelClass> trailer, RecyclerView recyc_trailer) {

            this.context=detailsActivity;
            this.tail=trailer;
            this.trailerRecycler=recyc_trailer;
        }

        @Override
        protected String doInBackground(String... strings) {

            String id = strings[0];

            String url = "https://api.themoviedb.org/3/movie/"+id+"/videos?api_key=a94040b9f54a45b33a89e8978c354b86";
            URL url1 = null;
            try {
                url1 = new URL(url);

                HttpURLConnection httpURLConnection = (HttpURLConnection) url1.openConnection();
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.connect();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                String line = " ";
                while ((line = bufferedReader.readLine()) != null) {

                    stringBuilder.append(line);
                }
                return stringBuilder.toString();

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            tail=new ArrayList<TrailerModelClass>();


            try {
                JSONObject jsonObject = new JSONObject(s);
                JSONArray results = jsonObject.getJSONArray("results");
                for (int i = 0; i < results.length(); i++) {

                    JSONObject object = results.getJSONObject(i);
                    String id = object.getString("id");
                    String key = object.getString("key");
                    String name = object.getString("name");

                    //Toast.makeText(context, id+"\n"+key+"\n"+name, Toast.LENGTH_SHORT).show();

                    TrailerModelClass trailers = new TrailerModelClass(id,key, name);
                    tail.add(trailers);
                }

                TrailerAdapter trailerAdapter = new TrailerAdapter(context, tail);
                recyc_trailer.setAdapter(trailerAdapter);
                recyc_trailer.setLayoutManager(new LinearLayoutManager(context));
            } catch (JSONException e) {
                e.printStackTrace();

            }
        }
    }








}
